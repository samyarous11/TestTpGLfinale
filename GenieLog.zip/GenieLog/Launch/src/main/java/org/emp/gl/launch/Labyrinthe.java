/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.launch;

import org.emp.gl.guicontrole.ChangeDirection;
import org.emp.gl.lookup.Lookup;
import org.emp.gl.TimerNotifier.TimerInform;
import org.emp.gl.robot.Rebot;


/**
 *
 * @author sami
 */
public class Labyrinthe {

     
    
    /**
     * @param args the command line arguments
     */
      static  {
       Lookup.getInstance().register(Rebot.class,new Rebot());
       Lookup.getInstance().register(TimerInform.class,new TimerInform());
       
      
      }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
       Rebot rebot=(Rebot) Lookup.getInstance().getService(ChangeDirection.class);
       TimerInform timer=Lookup.getInstance().getService(Timer.class);
       
        timer.addsub(rebot);
        timer.run();
        
        ToucheControle gui=new ToucheControle();
        gui.setVisible(true);   
         
        
    }

    
}
