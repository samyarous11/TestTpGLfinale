/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.guicontrole;

/**
 *
 * @author sami
 */
public interface ChangeDirection {
    
    
    public  void changeDerctionUp();
    public  void changeDerctiondown();
    public  void changeDerctionRight();
    public  void changeDerctionLeft();
}
