/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.timerinformwithdelegation;


import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import org.emp.gl.rebotsinterface.Moving;

/**
 *
 * @author sami
 */
public class TimerIform extends TimerTask  {

    

            
    
    @Override
    public void run() {
    

       TimerTask t = new TimerTask() {			
			@Override
			public void run() {
                         
                            notify_subs();
   
                        }
		};
           Timer tt = new Timer() ;
            tt.scheduleAtFixedRate(t, 0, 1000);
    }
    
    Set<Moving> ObserverColection= new HashSet<Moving>();
    public void addsub(Moving o){
         ObserverColection.add(o);
     }
     // suppermer
     public void removesub(Moving o){
         ObserverColection.remove(o);
     }
     //pour appler les gens following
     public void notify_subs(){
      for(Moving sub : ObserverColection )
            sub.moveDirectly();
    
     }
    
   }
    
    
    
     
 }
    

