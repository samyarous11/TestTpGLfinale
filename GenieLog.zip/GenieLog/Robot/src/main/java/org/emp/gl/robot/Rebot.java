/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;



import org.emp.gl.rebotsinterface.Moving;
import org.emp.gl.guicontrole.ChangeDirection;

/**
 *
 * @author sami
 */
public  class Rebot implements ChangeDirection,Moving  {
    

    


    
     int posx=0;
    int posy=0;
    
    
    
    
    protected RebotState state=new StateUp(this);
    
   
     public boolean limiteposition(){
         
    return posx >=0 && posx <10 && posy>=0 &&posy<10 ;
    }
    
   public void setState(RebotState state){
       this.state=state;
   }

    @Override
    public void changeDerctionUp() {
        state.changeDerctionUp();
    }
    @Override
    public void changeDerctiondown() {
        state.changeDerctiondown();
    }
    @Override
    public void changeDerctionRight() {
        state.changeDerctionRight();
    }
    @Override
    public void changeDerctionLeft() {
        state.changeDerctionLeft();
    }
    
  

    @Override
    public void moveDirectly() {
    state.moveDirectly();
    }

    

    
    
}
