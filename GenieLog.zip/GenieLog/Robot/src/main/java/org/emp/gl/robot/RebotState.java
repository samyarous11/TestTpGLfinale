/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;

/**
 *
 * @author sami
 */
public abstract class RebotState {
    protected Rebot rebot;
    
    public RebotState(Rebot rebot) {
        this.rebot = rebot;
    }

   
    
    
    
    public abstract void changeDerctionUp();
    public abstract void changeDerctiondown();
    public abstract void changeDerctionRight();
    public abstract void changeDerctionLeft();

    public abstract void moveDirectly();
    
}