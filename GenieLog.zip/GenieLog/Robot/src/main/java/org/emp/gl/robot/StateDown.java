/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;

/**
 *
 * @author sami
 */
public class StateDown extends RebotState {

    public StateDown(Rebot rebot) {
        super(rebot);
    }

  private ToucheControle controle = new ToucheControle();
    
    @Override
    public void changeDerctionUp() {}

    @Override
    public void changeDerctiondown() {
    rebot.setState(new StateDown(rebot));
    }

    @Override
    public void changeDerctionRight() {
    rebot.setState(new StateRight(rebot));
    }

    @Override
    public void changeDerctionLeft() {
        rebot.setState(new StateLeft(rebot));
        
    }

    @Override
    public void moveDirectly() {
    if(controle.matRebot[rebot.posx][rebot.posy-1]== 1||  controle.limiteposition() ){
            System.out.println("impossible to move in this direction");
        }
        else{
            controle.matRebot[rebot.posx][rebot.posy]=0;
            controle.matRebot[rebot.posx][rebot.posy-1]=8;
            controle.posy--;
            controle.afficherMatrice();
            
        } 
    }

   
}
