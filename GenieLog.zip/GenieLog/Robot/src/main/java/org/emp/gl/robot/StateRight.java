/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.robot;

/**
 *
 * @author sami
 */
public class StateRight extends RebotState {

     private ToucheControle controle = new ToucheControle();
    
    public StateRight(Rebot rebot) {
        super(rebot);
    }


    @Override
    public void changeDerctionUp() {
    rebot.setState(new StateUp(rebot));
    }

    @Override
    public void changeDerctiondown() {
       rebot.setState(new StateDown(rebot));    
    }

    @Override
    public void changeDerctionRight() {
    rebot.setState(new StateRight(rebot));
    }

    @Override
    public void changeDerctionLeft() {
        System.out.println(" impossible de tourner de cette direction");
    
    }

    @Override
    public void moveDirectly() {
    if( controle.matRebot[rebot.posx+1][rebot.posy]== 1||  controle.limiteposition() ){
            System.out.println("impossible to move in this direction");
        }
        else{
             controle.matRebot[rebot.posx][rebot.posy]=0;
             controle.matRebot[1+rebot.posx][rebot.posy]=8;
             controle.posx++;
             controle.afficherMatrice();
        } 
    }
    
}
