/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.launcher;

import org.emp.gl.guicontrole.ChangeDirection;
import org.emp.gl.lookup.Lookup;
import org.emp.gl.rebotsinterface.Moving;
import org.emp.gl.robot.Rebot;



/**
 *
 * @author sami
 */
public class mainLabyrenthe {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        
      
      Lookup.getInstance().register(Moving.class,new Rebot());
      Rebot rebot=(Rebot) Lookup.getInstance().getService(ChangeDirection.class);
      
     Lookup.getInstance().register(Moving.class,new TimerInform());
      
      
      
        
        
        
        
    }
    
}
