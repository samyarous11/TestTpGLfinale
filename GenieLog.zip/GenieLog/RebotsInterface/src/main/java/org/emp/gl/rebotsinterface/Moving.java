/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebotsinterface;

import java.beans.PropertyChangeListener;

/**
 *
 * @author sami
 */
public interface Moving {
    public  void moveDirectly();
}
